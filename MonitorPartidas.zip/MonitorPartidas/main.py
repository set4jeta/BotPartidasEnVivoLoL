import nextcord
import requests
import aiohttp
import asyncio
import os
import json
from nextcord.ext import commands
from datetime import datetime, timedelta
import pytz

intents = nextcord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="/", intents=intents)

API_KEY = "0TvQnueqKa5mxJntVWt0w4LpLfEkrV1Ta8rQBb9Z"
HEADERS = {"x-api-key": API_KEY}
SLUG_PRIORITY = [
    "lec", "lpl", "lck", "lta_n", "lta_s", "lck_challengers_league",
    "superliga", "nlc", "lfl", "nacl", "lvp", "turkiye-sampiyonluk-ligi",
    "lcp", "pcs", "primeleague", "arabian_league", "liga_portuguesa",
    "north_regional_league", "south_regional_league", "ljl-japan", "cd",
    "tft_esports", "hellenic_legends_league", "hitpoint_masters",
    "roadoflegends", "rift_legends"
]

CONFIG_FILE = "config.json"


def load_config():
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r') as f:
                return json.load(f)
    except Exception as e:
        print(f"Error cargando configuración: {e}")
    return {"notification_channel_id": None}


def save_config(config):
    try:
        with open(CONFIG_FILE, 'w') as f:
            json.dump(config, f)
    except Exception as e:
        print(f"Error guardando configuración: {e}")


config = load_config()
notified_matches = set()


async def get_network_time():
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get("https://www.google.com",
                                   timeout=2) as response:
                if response.status == 200:
                    date_header = response.headers.get("Date")
                    return datetime.strptime(
                        date_header,
                        "%a, %d %b %Y %H:%M:%S GMT").replace(tzinfo=pytz.UTC)
    except:
        return datetime.now(pytz.utc)


def get_live_stats(game_id):
    try:
        response = requests.get(
            f"https://feed.lolesports.com/livestats/v1/window/{game_id}",
            headers=HEADERS,
            timeout=10)
        return response.json() if response.status_code == 200 else None
    except Exception as e:
        print(f"Error en get_live_stats: {str(e)}")
        return None


async def fetch_live_matches():
    try:
        async with aiohttp.ClientSession() as session:
            now = await get_network_time()
            try:
                schedule = await session.get(
                    "https://esports-api.lolesports.com/persisted/gw/getSchedule?hl=en-US",
                    headers=HEADERS)
                if schedule.status != 200:
                    print(f"Error API Schedule: {schedule.status}")
                    return []
                data = await schedule.json()
            except Exception as e:
                print(f"Error al obtener schedule: {str(e)}")
                return []

            events = data.get("data", {}).get("schedule", {}).get("events", [])
            live_matches = []

            for event in events:
                try:
                    if event.get("type") != "match":
                        continue

                    start_time = datetime.fromisoformat(
                        event['startTime'].replace(
                            'Z', '+00:00')).replace(tzinfo=pytz.UTC)
                    if (now - start_time) > timedelta(hours=6):
                        continue

                    event_id = event.get("match", {}).get("id")
                    if not event_id:
                        continue

                    details = await session.get(
                        f"https://esports-api.lolesports.com/persisted/gw/getEventDetails?hl=en-US&id={event_id}",
                        headers=HEADERS)
                    if details.status != 200:
                        continue

                    details_data = await details.json()
                    match_data = details_data.get("data",
                                                  {}).get("event",
                                                          {}).get("match", {})
                    games = match_data.get("games", [])

                    for game in games:
                        if game.get("state") == "inProgress":
                            slug = event.get("league", {}).get("slug", "")
                            priority = SLUG_PRIORITY.index(
                                slug) if slug in SLUG_PRIORITY else float(
                                    'inf')

                            # Obtener victorias de equipos
                            team_wins = [
                                team.get("result", {}).get("gameWins", 0)
                                for team in match_data.get("teams", [])
                            ]

                            live_matches.append({
                                "event":
                                event,
                                "game_id":
                                game.get("id"),
                                "priority":
                                priority,
                                "match_data":
                                match_data,
                                "start_time":
                                start_time,
                                "game_number":
                                game.get("number", 1),  # Nuevo campo
                                "team_wins":
                                team_wins  # Nuevo campo
                            })
                            print(
                                f"[LIVE] Juego {game.get('id')} en progreso: {slug}"
                            )

                except Exception as e:
                    print(f"Error procesando evento: {str(e)}")
                    continue

            live_matches.sort(key=lambda x: (x["priority"], x["start_time"]))
            return live_matches

    except Exception as e:
        print(f"Error crítico en fetch_live_matches: {str(e)}")
        return []


@bot.command(name="setchannel")
@commands.has_permissions(administrator=True)
async def set_channel(ctx):
    config["notification_channel_id"] = ctx.channel.id
    save_config(config)
    await ctx.send(f"✅ Canal configurado: {ctx.channel.mention}")


@bot.command(name="partida")
async def partida(ctx):
    try:
        matches = await fetch_live_matches()
        print(f"[DEBUG] Partidos encontrados: {len(matches)}")

        if not matches:
            await ctx.send("🔍 No hay partidas en vivo actualmente")
            return

        for match in matches[:3]:
            try:
                game_id = match["game_id"]
                event = match["event"]
                match_data = match["match_data"]
                teams = match_data.get("teams", [])
                game_number = match.get("game_number", 1)  # Cambio clave
                team_wins = match.get("team_wins", [0, 0])  # Cambio clave

                live_data = get_live_stats(game_id)
                if not live_data or "gameMetadata" not in live_data:
                    continue

                blue_metadata = live_data["gameMetadata"].get(
                    "blueTeamMetadata", {})
                red_metadata = live_data["gameMetadata"].get(
                    "redTeamMetadata", {})

                blue_team = next(
                    (t for t in teams
                     if t.get("id") == blue_metadata.get("esportsTeamId")),
                    None)
                red_team = next(
                    (t for t in teams
                     if t.get("id") == red_metadata.get("esportsTeamId")),
                    None)

                if not blue_team or not red_team:
                    continue

                # Determinar qué equipo es azul/rojo para el marcador
                blue_index = 0 if teams[0]["id"] == blue_team["id"] else 1
                red_index = 1 - blue_index
                blue_score = team_wins[blue_index]
                red_score = team_wins[red_index]

                # Construir embed
                embed = nextcord.Embed(
                    title=
                    f"{event.get('league',{}).get('name', 'Liga')} - {blue_team.get('name', 'Azul')} vs {red_team.get('name', 'Rojo')}",
                    color=0x0099ff)

                # Jugadores
                blue_players = [
                    f"{p.get('summonerName', 'Jugador')} ({p.get('championId', '?')})"
                    for p in blue_metadata.get("participantMetadata", [])
                ]
                red_players = [
                    f"{p.get('summonerName', 'Jugador')} ({p.get('championId', '?')})"
                    for p in red_metadata.get("participantMetadata", [])
                ]

                embed.add_field(
                    name=
                    f"🔵 {blue_team.get('name', 'Azul')}",  # <-- Mantener referencia al nombre
                    value="\n".join(blue_players),
                    inline=False)
                embed.add_field(
                    name=
                    f"🔴 {red_team.get('name', 'Rojo')}",  # <-- Mantener referencia al nombre
                    value="\n".join(red_players),
                    inline=False)

                # Resultado parcial (CAMBIOS PRINCIPALES AQUÍ)
                strategy = match_data.get("strategy", {})
                strategy_count = strategy.get("count", 1)

                if strategy_count > 1:
                    footer_text = f"{strategy.get('type', 'BO').upper()}{strategy_count} ({blue_score}-{red_score}) | 🎮 Juego {game_number} de {strategy_count}"
                else:
                    footer_text = f"{strategy.get('type', 'BO').upper()}{strategy_count}"

                embed.set_footer(text=footer_text)

                await ctx.send(embed=embed)
                await asyncio.sleep(1)

            except Exception as e:
                print(f"Error procesando partido: {str(e)}")
                continue

    except Exception as e:
        print(f"Error en /partida: {str(e)}")
        await ctx.send("⚠️ Error al obtener partidas")


async def check_live_matches_background():
    await bot.wait_until_ready()
    print("[BACKGROUND] Servicio iniciado")

    while not bot.is_closed():
        try:
            channel_id = config.get("notification_channel_id")
            if not channel_id:
                await asyncio.sleep(120)
                continue

            channel = bot.get_channel(channel_id)
            if not channel:
                print(f"[ERROR] Canal {channel_id} no existe")
                await asyncio.sleep(120)
                continue

            matches = await fetch_live_matches()
            print(f"[BACKGROUND] Partidos detectados: {len(matches)}")

            for match in matches:
                game_id = match["game_id"]
                if game_id in notified_matches:
                    continue

                try:
                    event = match["event"]
                    match_data = match["match_data"]
                    teams = match_data.get("teams", [])
                    game_number = match.get("game_number", 1)  # Cambio clave
                    team_wins = match.get("team_wins", [0, 0])  # Cambio clave

                    live_data = get_live_stats(game_id)
                    if not live_data or "gameMetadata" not in live_data:
                        continue

                    blue_metadata = live_data["gameMetadata"].get(
                        "blueTeamMetadata", {})
                    red_metadata = live_data["gameMetadata"].get(
                        "redTeamMetadata", {})

                    blue_team = next(
                        (t for t in teams
                         if t.get("id") == blue_metadata.get("esportsTeamId")),
                        None)
                    red_team = next(
                        (t for t in teams
                         if t.get("id") == red_metadata.get("esportsTeamId")),
                        None)

                    if not blue_team or not red_team:
                        continue

                    # Determinar marcador correcto
                    blue_index = 0 if teams[0]["id"] == blue_team["id"] else 1
                    red_index = 1 - blue_index
                    blue_score = team_wins[blue_index]
                    red_score = team_wins[red_index]

                    embed = nextcord.Embed(
                        title=
                        f"🎮 ¡Partido en vivo! {blue_team.get('name', 'Azul')} vs {red_team.get('name', 'Rojo')}",
                        color=0x00ff00)

                    blue_players = [
                        f"{p.get('summonerName', 'Jugador')} ({p.get('championId', '?')})"
                        for p in blue_metadata.get("participantMetadata", [])
                    ]
                    red_players = [
                        f"{p.get('summonerName', 'Jugador')} ({p.get('championId', '?')})"
                        for p in red_metadata.get("participantMetadata", [])
                    ]

                    embed.add_field(
                        name=
                        f"🔵 {blue_team.get('name', 'Azul')}",  # <-- Mantener referencia al nombre
                        value="\n".join(blue_players),
                        inline=False)
                    embed.add_field(
                        name=
                        f"🔴 {red_team.get('name', 'Rojo')}",  # <-- Mantener referencia al nombre
                        value="\n".join(red_players),
                        inline=False)

                    strategy = match_data.get("strategy", {})
                    strategy_count = strategy.get("count", 1)

                    if strategy_count > 1:
                        footer_text = f"{strategy.get('type', 'BO').upper()}{strategy_count} ({blue_score}-{red_score}) | 🎮 Juego {game_number} de {strategy_count}"
                    else:
                        footer_text = f"{strategy.get('type', 'BO').upper()}{strategy_count}"

                    embed.set_footer(text=footer_text)

                    await channel.send(embed=embed)
                    notified_matches.add(game_id)
                    print(f"[NOTIFICACIÓN] Enviado: {game_id}")

                except Exception as e:
                    print(f"Error enviando notificación: {str(e)}")

            await asyncio.sleep(120)

        except Exception as e:
            print(f"[BACKGROUND ERROR] {str(e)}")
            await asyncio.sleep(60)


@bot.event
async def on_ready():
    print(f'Bot conectado como {bot.user.name}')
    bot.loop.create_task(check_live_matches_background())


token = os.getenv("DISCORD_TOKEN")
if token:
    bot.run(token)
else:
    print("❌ Error: Token no configurado")
